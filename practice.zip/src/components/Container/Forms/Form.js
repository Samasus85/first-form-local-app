

import React from 'react';
import styled from 'styled-components'
import Input from '../../Input/Input';
import Button from '../../UI/Buttons/Button';
import Container from '../Container';

const StyleForm = styled.button`
width: 500px;
height: 500px;
background: ${props => (props.primary ? "blue" : "red")};
border-color: red;
margin: 0 auto;
margin-top: 100px;
border-radius: 10px;
box-shadow: 0 0 10px rgba(0,0,0,0.5)

`
const FormContainer = styled.div`
padding-top: 60px;
`

const Form = () => {

    return <StyleForm>
        <FormContainer>
            <h1>User story</h1>
            <Container>
                <Input />
            </Container>
            <Container>
                <Input />
            </Container>
            <Container>
                <Input />
            </Container>
            <Button />
        </FormContainer>
        <Button />
    </StyleForm>
}
export default Form;
