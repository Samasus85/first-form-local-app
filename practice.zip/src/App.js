import './App.css';
import Container from './components/Container/Container';
import Button from './components/UI/Buttons/Button';

function App() {
  return (
    <div className="App">
      <Container>
        <Button title='Отправить' />
      </Container>
      <Button title='Получить' primary={true} />
    </div>
  );
}

export default App;
